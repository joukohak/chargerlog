#include "STM8S.h"
#include "setup.h"
#include "timer1.h"
#include "gui.h"




//uint8_t 	seconds=0,minutes=0,hours=0;
//uint8_t 	Vbat10 =0,VbatMax =0,VbatMin =255;



@near unsigned char 	BatLog[240];
@near unsigned char 	BatLogm[240];
@near unsigned char 	BatLogh[240];






unsigned char TXByte;		// Value sent over UART when Transmit() is called
unsigned char RXByte;		// Value recieved once hasRecieved is set

unsigned char hasReceived=0;			// Lets the program know when a byte is received
unsigned char ADCDone=0;				// ADC Done flag, rising edge trigger



void Receive(void);


void main()
{		
	clock_setup();
	GPIO_setup();
	ADC1_setup();
	TIM1_Config();
	UART1_Config();
	delay_ms(1000);
		
	hasReceived = 0;
	ADCDone = 0;
	  // Auto preload, upcounter , timer1 enable
	TIM1->CR1  = 0x81; 	//start 100ms AD conversions
	
	ADC1->CSR  = 0x24;
	//	ADC1 ON , Single conversion mode
	ADC1->CR1 = 0x01;
	

	
	while(1)
	{
		if (hasReceived==1)			// If the device has received a value
		{
			Receive();
		}
		
	}

 
	
}


