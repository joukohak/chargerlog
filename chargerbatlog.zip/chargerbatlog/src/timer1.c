/**
  * @brief  Configure TIM1 to allow 1 sec rtc
  * @param  None
  * @retval None
  */
#include "stm8s.h"	
	
void TIM1_Config(void)
{
  //TIM1_DeInit();
	
	
  /* Time base configuration */

	
  
	TIM1->PSCRH = 0x07;      // prescaler 1999+1 = 1 kHz = 1ms
  TIM1->PSCRL = 0xCF;
	TIM1->ARRH  = 0x07;			 // div 2000 = 2s
  TIM1->ARRL  = 0xCF;				// 1999+1 = 07CF
 
  
  // Auto preload, upcounter ,no one pulse mode,counter disable 
	TIM1->CR1  = 0x80;
	//  Update as TRGO trigger to ADC
	TIM1->CR2  = 0x20;
	
// Timer 2 init 	
	TIM2->PSCR 	= 0x07;   				// Prescaler 2MHz clk /128= 15625Hz
	TIM2->ARRH  = 0x3D;			 // period   1s  div 15625 0x3D09
  TIM2->ARRL  = 0x09;
	// TIM2 CCR1 PWM OUTPUT
	// TIM2->CCMR1 = 0x68;
	// TIM2 CCR3 PWM OUTPUT
	//TIM2->CCMR3 = 0x68;
	
	// Timer2 CCR1 PWM period
	//TIM2->CCR1H = 0x13;
  //TIM2->CCR1L = 0x80;
	
	//TIM2->CCER1 = 0x01;
	//TIM2->CCER2 = 0x01;
	// counter enable
	TIM2->CR1  = 0x81;
	TIM2->EGR  = 0x01;  // timer 2 event gen. reg.
	TIM2->IER  = 0x01;  // timer 2 update interrupt enable
  
}

