#include "STM8S.h"

void GPIO_setup1(void);



void clock_setup(void)
{
	CLK_DeInit();
	
	CLK_HSICmd(ENABLE);
	while(CLK_GetFlagStatus(CLK_FLAG_HSIRDY) == FALSE);
	CLK_ClockSwitchCmd(ENABLE);
	CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV8);  // 2MHz clock
	CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1);
	
	CLK->PCKENR1 = 0xA8;  // TIM1, TIM2 , UART1 clk enable
  CLK->PCKENR2 = 0x08; //ADC1 clk enable
	
	CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSI, 
	DISABLE, CLK_CURRENTCLOCKSTATE_ENABLE);
	
}


void GPIO_setup(void)
{
	//port B	
	//GPIOB->DDR = 0x20;  // B5 output open drain  
	//GPIOB->CR1 = 0x20;  //pullup B5
	//GPIOB->CR2 = 0x10;  //interrupt B4 no pullup
	//GPIOB->ODR = 0x20;  // BLE PWRC B5 output=1
	
	//GPIOA->DDR = 0x08;  //A3 out  
	//GPIOA->CR1 = 0x08;  //push pull



	// UART1 TXD =1 
	GPIOD->ODR = 0x20;
	// gpioD5 TXD out,others input
	GPIOD->DDR = 0x20;
	// ADC CH3,4 floating input 
	GPIOD->CR1 = 0xF3;


}

void ADC1_setup(void)
{
	// bit5 EOCIE off , bit3-0 CH 4
	ADC1->CSR  = 0x04;
	// fmaster/2 clock, single conversion ,ADC off
  ADC1->CR1  = 0x00;
	// external trigger TIM1, Data align right
  ADC1->CR2  = 0x48;
	// No data buffer and overrrun flag
  ADC1->CR3  = 0x00;
	// input schmit trigger disable CH3,4
	ADC1->LTRH = 0x00;
  ADC1->LTRL = 0x18;
	//ADC on
	ADC1->CR1  = 0x01;

}
void UART1_Config(void)
{
  //UART1_DeInit();
	/* EVAL COM (UART) configuration -----------------------------------------*/
  /* USART configured as follow:
        - BaudRate = 9600 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Receive and transmit enabled
        - UART Clock disabled*/
  

  // Enable the UART Receive interrupt: this interrupt is generated when the UART
  //  receive data register is not empty 
 // UART1_ITConfig(UART1_IT_RXNE, ENABLE);
  
 

 
  
  UART1->BRR2 = 0x00;  // Set UART1_BRR2 2MHz/ 9600 0x00D0 
  UART1->BRR1 = 0x0D;  // Set UART1_BRR1 2MHz/ 9600  0x0D
  

  UART1->CR2 = 0x2C;  /* Set UART1_CR2 to RX/TX EN, RXIE value 0x2C */

    /* Enable general interrupts */
  enableInterrupts();
}
